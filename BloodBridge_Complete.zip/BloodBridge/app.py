from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "bloodbridge-demo-secret")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///bloodbridge.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

# The app has no login system yet, so the donor dashboard demonstrates the
# workflow using a single fixed donor record. Swap this for a real logged-in
# donor id once authentication is added.
DEMO_DONOR_ID = 1


# ---------------------------------------------------------------------------
# MODELS
# ---------------------------------------------------------------------------

class Donor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    blood_group = db.Column(db.String(5), nullable=False)
    location = db.Column(db.String(120), nullable=False)
    distance = db.Column(db.Float, default=0)
    availability = db.Column(db.String(30), default="Available")
    reliability = db.Column(db.String(30), default="Good")
    phone = db.Column(db.String(30), default="")
    total_donations = db.Column(db.Integer, default=0)


class DonationRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    donor_id = db.Column(db.Integer, db.ForeignKey("donor.id"), nullable=False)
    donation_date = db.Column(db.String(30), nullable=False)
    hospital = db.Column(db.String(150), nullable=False)
    blood_group = db.Column(db.String(5), nullable=False)
    status = db.Column(db.String(30), default="Completed")


class BloodRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    request_code = db.Column(db.String(30), unique=True, nullable=False)
    blood_group = db.Column(db.String(5), nullable=False)
    units = db.Column(db.Integer, nullable=False)
    hospital = db.Column(db.String(150), nullable=False)
    location = db.Column(db.String(150), default="")
    city = db.Column(db.String(80), default="Karachi")
    requester_name = db.Column(db.String(120), default="")
    phone = db.Column(db.String(30), default="")
    notes = db.Column(db.Text, default="")
    urgency = db.Column(db.String(30), nullable=False)
    status = db.Column(db.String(50), default="Searching Donors")
    matched_donor = db.Column(db.String(120), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class DonorRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.Integer, db.ForeignKey("blood_request.id"), nullable=False)
    donor_id = db.Column(db.Integer, db.ForeignKey("donor.id"), nullable=False)
    status = db.Column(db.String(30), default="Pending")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    blood_request = db.relationship("BloodRequest")
    donor = db.relationship("Donor")


class BloodBank(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    location = db.Column(db.String(150), nullable=False)
    distance = db.Column(db.Float, default=0)
    is_open = db.Column(db.Boolean, default=True)


class BloodBankStock(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bank_id = db.Column(db.Integer, db.ForeignKey("blood_bank.id"), nullable=False)
    blood_group = db.Column(db.String(5), nullable=False)
    units = db.Column(db.Integer, default=0)

    bank = db.relationship("BloodBank", backref="stock")


# ---------------------------------------------------------------------------
# SEED DATA
# ---------------------------------------------------------------------------

def seed_database():
    if Donor.query.count() == 0:
        donors = [
            Donor(name="Ahmed Khan", blood_group="O+", location="Gulshan-e-Iqbal",
                  distance=2.4, availability="Available", reliability="Excellent",
                  phone="0300 1234567", total_donations=12),
            Donor(name="Sara Malik", blood_group="A+", location="Clifton",
                  distance=3.1, availability="Available", reliability="Excellent",
                  phone="0301 2345678", total_donations=8),
            Donor(name="Rayan Hussain", blood_group="B+", location="Nazimabad",
                  distance=4.2, availability="Available", reliability="Good",
                  phone="0302 3456789", total_donations=5),
            Donor(name="Fatima Ali", blood_group="O-", location="DHA Phase 5",
                  distance=5.3, availability="Available", reliability="Excellent",
                  phone="0303 4567890", total_donations=9),
            Donor(name="Hassan Ahmed", blood_group="AB+", location="Bahadurabad",
                  distance=6.0, availability="Available", reliability="Good",
                  phone="0304 5678901", total_donations=3),
            Donor(name="Zainab Noor", blood_group="B-", location="PECHS",
                  distance=7.2, availability="Unavailable", reliability="Good",
                  phone="0305 6789012", total_donations=6),
        ]
        db.session.add_all(donors)
        db.session.commit()

        db.session.add_all([
            DonationRecord(donor_id=1, donation_date="12 Jun 2026", hospital="City Hospital",
                            blood_group="O+", status="Completed"),
            DonationRecord(donor_id=1, donation_date="03 Mar 2026", hospital="Jinnah Medical Centre",
                            blood_group="O+", status="Completed"),
            DonationRecord(donor_id=1, donation_date="18 Nov 2025", hospital="Aga Khan Hospital",
                            blood_group="O+", status="Completed"),
        ])
        db.session.commit()

    if BloodBank.query.count() == 0:
        banks = [
            ("City Blood Centre", "Gulshan-e-Iqbal, Karachi", 2.8, True,
             {"O+": 8, "A+": 5, "B+": 4, "AB+": 2}),
            ("LifeCare Blood Bank", "North Nazimabad, Karachi", 5.4, True,
             {"O+": 6, "A-": 3, "B+": 7, "O-": 2}),
            ("Hope Blood Centre", "Clifton, Karachi", 7.1, True,
             {"A+": 9, "O+": 4, "AB+": 5, "B-": 2}),
        ]
        for name, location, distance, is_open, stock in banks:
            bank = BloodBank(name=name, location=location, distance=distance, is_open=is_open)
            db.session.add(bank)
            db.session.flush()
            for group, units in stock.items():
                db.session.add(BloodBankStock(bank_id=bank.id, blood_group=group, units=units))
        db.session.commit()


# Run once at import time so the database exists and is seeded whether the
# app is started with `python app.py`, `flask run`, or a WSGI server.
with app.app_context():
    db.create_all()
    seed_database()


# ---------------------------------------------------------------------------
# ROUTES
# ---------------------------------------------------------------------------

@app.route("/")
def home():
    return render_template("index.html", active="home")


@app.route("/donors")
def donors():
    blood = request.args.get("blood", "").strip()
    location = request.args.get("location", "").strip().lower()
    availability = request.args.get("availability", "").strip()

    query = Donor.query
    if blood:
        query = query.filter_by(blood_group=blood)
    if location:
        query = query.filter(Donor.location.ilike(f"%{location}%"))
    if availability:
        query = query.filter_by(availability=availability)

    donor_list = query.order_by(Donor.distance.asc()).all()
    return render_template(
        "donors.html",
        active="donors",
        donors=donor_list,
        blood_groups=BLOOD_GROUPS,
        selected_blood=blood,
        selected_location=request.args.get("location", ""),
        selected_availability=availability,
    )


@app.route("/request", methods=["GET", "POST"])
def create_request():
    if request.method == "POST":
        blood_group = request.form.get("blood_group", "").strip()
        units_raw = request.form.get("units", "1").strip()
        hospital = request.form.get("hospital", "").strip()
        location = request.form.get("location", "").strip()
        city = request.form.get("city", "Karachi").strip()
        requester_name = request.form.get("requester", "").strip()
        phone = request.form.get("phone", "").strip()
        notes = request.form.get("notes", "").strip()
        urgency = request.form.get("urgency", "High").strip()

        errors = []
        if not blood_group:
            errors.append("Please select a blood group.")
        if not hospital:
            errors.append("Please enter the hospital name.")
        if not requester_name:
            errors.append("Please enter your name.")
        if not phone:
            errors.append("Please enter a contact number.")

        try:
            units = max(1, int(units_raw.split()[0]))
        except (ValueError, IndexError):
            units = 1

        if errors:
            for message in errors:
                flash(message)
            return render_template(
                "request.html", active="request", form=request.form
            )

        last = BloodRequest.query.order_by(BloodRequest.id.desc()).first()
        next_number = (last.id + 2048) if last else 2048
        code = f"REQ-{next_number}"

        new_request = BloodRequest(
            request_code=code,
            blood_group=blood_group,
            units=units,
            hospital=hospital,
            location=location,
            city=city or "Karachi",
            requester_name=requester_name,
            phone=phone,
            notes=notes,
            urgency=urgency,
        )
        db.session.add(new_request)
        db.session.commit()

        # Track this browser's active request via session rather than a
        # single shared "latest request" so concurrent visitors don't clash.
        session["active_request_code"] = code

        flash("Emergency request created successfully!")
        return redirect(url_for("status", code=code))

    return render_template("request.html", active="request", form={})


@app.route("/status")
def status():
    code = request.args.get("code") or session.get("active_request_code")
    blood_request = None
    if code:
        blood_request = BloodRequest.query.filter_by(request_code=code).first()

    stage_order = ["Searching Donors", "Donor Matched", "Blood Arranged"]
    current_stage = stage_order.index(blood_request.status) if blood_request and blood_request.status in stage_order else 0

    return render_template(
        "status.html",
        active="status",
        blood_request=blood_request,
        current_stage=current_stage,
    )


@app.route("/blood-banks")
def blood_banks():
    banks = BloodBank.query.order_by(BloodBank.distance.asc()).all()
    return render_template("blood_banks.html", active="banks", banks=banks)


@app.route("/donor-dashboard")
def donor_dashboard():
    donor = db.session.get(Donor, DEMO_DONOR_ID)
    if not donor:
        flash("Demo donor profile not found.")
        return redirect(url_for("home"))

    pending = (
        DonorRequest.query.filter_by(donor_id=donor.id, status="Pending")
        .join(BloodRequest)
        .order_by(DonorRequest.created_at.desc())
        .all()
    )
    history = (
        DonationRecord.query.filter_by(donor_id=donor.id)
        .order_by(DonationRecord.id.desc())
        .all()
    )

    return render_template(
        "donor_dashboard.html",
        active="dashboard",
        donor=donor,
        pending_requests=pending,
        history=history,
    )


@app.route("/toggle-availability/<int:donor_id>", methods=["POST"])
def toggle_availability(donor_id):
    donor = db.session.get(Donor, donor_id)
    if not donor:
        return jsonify({"success": False, "message": "Donor not found"}), 404

    donor.availability = "Unavailable" if donor.availability == "Available" else "Available"
    db.session.commit()

    return jsonify({"success": True, "availability": donor.availability})


@app.route("/donor-request/<int:donor_request_id>/accept", methods=["POST"])
def accept_donor_request(donor_request_id):
    link = db.session.get(DonorRequest, donor_request_id)
    if not link:
        return jsonify({"success": False, "message": "Request not found"}), 404

    link.status = "Accepted"
    link.blood_request.status = "Donor Matched"
    link.blood_request.matched_donor = link.donor.name
    db.session.commit()

    return jsonify({"success": True, "message": f"Request {link.blood_request.request_code} accepted."})


@app.route("/donor-request/<int:donor_request_id>/reject", methods=["POST"])
def reject_donor_request(donor_request_id):
    link = db.session.get(DonorRequest, donor_request_id)
    if not link:
        return jsonify({"success": False, "message": "Request not found"}), 404

    link.status = "Rejected"
    db.session.commit()

    return jsonify({"success": True, "message": f"Request {link.blood_request.request_code} rejected."})


@app.route("/request-donor/<int:donor_id>", methods=["POST"])
def request_donor(donor_id):
    donor = db.session.get(Donor, donor_id)
    if not donor:
        return jsonify({"success": False, "message": "Donor not found"}), 404

    code = session.get("active_request_code")
    blood_request = BloodRequest.query.filter_by(request_code=code).first() if code else None
    if not blood_request:
        blood_request = BloodRequest.query.order_by(BloodRequest.id.desc()).first()
    if not blood_request:
        return jsonify({"success": False, "message": "Create a blood request first"}), 400

    existing = DonorRequest.query.filter_by(
        request_id=blood_request.id, donor_id=donor.id
    ).first()

    if existing:
        return jsonify({"success": True, "message": "Donor already requested"})

    db.session.add(DonorRequest(
        request_id=blood_request.id,
        donor_id=donor.id,
        status="Pending"
    ))
    db.session.commit()

    return jsonify({"success": True, "message": f"Request sent to {donor.name}"})


@app.route("/api/donors")
def api_donors():
    donor_list = Donor.query.all()
    return jsonify([
        {
            "id": d.id,
            "name": d.name,
            "blood_group": d.blood_group,
            "location": d.location,
            "distance": d.distance,
            "availability": d.availability,
            "reliability": d.reliability,
        }
        for d in donor_list
    ])


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html", active=""), 404


@app.errorhandler(500)
def server_error(_error):
    return render_template("500.html", active=""), 500


if __name__ == "__main__":
    app.run(debug=True)

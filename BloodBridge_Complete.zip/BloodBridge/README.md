# BloodBridge — Flask + SQLite

Smart Blood Donation & Emergency Matching demo, backed by a real SQLite
database (via Flask-SQLAlchemy) instead of browser localStorage.

## 1. Set up a virtual environment

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate
```

## 2. Install dependencies

```bash
pip install -r requirements.txt
```

## 3. Run

```bash
python app.py
```

## 4. Open

http://127.0.0.1:5000

The SQLite database `bloodbridge.db` is created and seeded with demo
donors, a demo donation history and three blood banks automatically the
first time the app starts — including when run via `flask run` or a WSGI
server, not just `python app.py`.

## Pages / routes

- `/` — Home
- `/donors` — Find Donors (server-side search by blood group / location / availability)
- `/request` — Create an emergency blood request
- `/status` — Track a request's live status (remembered per browser session)
- `/blood-banks` — Registered blood banks with live stock levels
- `/donor-dashboard` — Donor view: toggle availability, accept/reject nearby requests, donation history
- `/api/donors` — JSON donor list

## What this project deliberately doesn't do

This is an academic/demo project, so a few things are intentionally out of
scope rather than "missing":

- **No authentication.** The donor dashboard always shows one fixed demo
  donor (`DEMO_DONOR_ID` in `app.py`). Add a login system before treating
  this as multi-user.
- **No SMS/email/push notifications.** "Notify Donors" is simulated by the
  donor simply seeing the request in their dashboard.
- **No real geolocation.** Distances are static seed values, not computed
  from coordinates.

## Notable fixes made to the original upload

1. **Two disconnected implementations were merged.** The static HTML/CSS/JS
   set used `localStorage` and had no real backend; the Flask+SQLite backend
   was missing the Blood Banks and Donor Dashboard pages entirely (they
   existed only as static demo HTML, not as Flask routes/templates). Both
   are now one working app.
2. **Broken asset paths.** The static HTML referenced `css/style.css` and
   `js/app.js`, but the uploaded files were flat (`style.css`, `app.js`)
   with no folders — the site would 404 on every asset if deployed as-is.
3. **Database only seeded when run directly.** `db.create_all()` and
   `seed_database()` were called inside `if __name__ == "__main__"`, so the
   database would never be created under `flask run` or a production WSGI
   server. Moved to run at import time.
4. **`app.js` didn't match the Flask backend.** The donor dashboard's
   Accept/Reject buttons and "Request Donor" buttons called JS functions
   that only wrote to `localStorage` — they never actually talked to the
   Flask API routes that already existed for this. Rewired to real
   `fetch()` calls against `/request-donor/<id>`, `/donor-request/<id>/accept`
   `/reject`, and `/toggle-availability/<id>`.
5. **Blood request form silently dropped data.** The Flask version of the
   request form only captured blood group, units, hospital and urgency —
   requester name, phone, location, city and notes were collected by the
   nicer static form but had nowhere to go in the database. Extended the
   `BloodRequest` model and form to capture and store all of it.
6. **Global "latest request" bug.** `/status` and `/request-donor` both
   picked "whichever `BloodRequest` has the highest id," so two people
   using the app at the same time would see and act on each other's
   requests. Now tracked per-browser via a session cookie.
7. **Orphan page.** No page linked to the donor dashboard at all. Added it
   to the shared navigation.
8. **Dead/fake button.** The status page's "Simulate Update" button just
   faked progress client-side, which is misleading next to a page that's
   otherwise showing real database state. Replaced with a "Refresh Status"
   link and progress that now reflects the request's real status.
9. **Missing pieces for a production-feeling app:** favicon, meta
   descriptions, consistent active-nav highlighting, flash-message styling,
   404/500 error pages, and a shared `base.html` so every page can't drift
   out of sync again.

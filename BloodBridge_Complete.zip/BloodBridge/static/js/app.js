/* ---------- TOAST MESSAGE ---------- */

function showToast(message, isError) {

  const oldToast = document.querySelector(".toast");

  if (oldToast) {
    oldToast.remove();
  }

  const toast = document.createElement("div");

  toast.className = "toast" + (isError ? " toast-error" : "");
  toast.textContent = message;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}


/* ---------- SHARED POST HELPER ---------- */

async function postJSON(url) {

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" }
  });

  let data = {};

  try {
    data = await response.json();
  } catch (err) {
    data = { success: false, message: "Unexpected server response." };
  }

  if (!response.ok && !data.message) {
    data.message = "Something went wrong. Please try again.";
  }

  return data;
}


/* ---------- DONOR SEARCH (request a donor) ---------- */

async function requestDonor(donorId, name) {

  try {

    const data = await postJSON(`/request-donor/${donorId}`);

    showToast(data.message || `Request sent to ${name}!`, !data.success);

  } catch (err) {

    showToast("Could not send the request. Please create a blood request first.", true);

  }

}


/* ---------- DONOR DASHBOARD ---------- */

async function toggleAvailability(donorId) {

  const toggle = document.getElementById("availabilityToggle");

  try {

    const data = await postJSON(`/toggle-availability/${donorId}`);

    if (data.success) {
      showToast(
        data.availability === "Available"
          ? "You are now available for blood requests."
          : "Your donor availability is now OFF."
      );
    } else {
      showToast(data.message || "Could not update availability.", true);
      if (toggle) toggle.checked = !toggle.checked;
    }

  } catch (err) {
    showToast("Could not update availability. Please try again.", true);
    if (toggle) toggle.checked = !toggle.checked;
  }

}


async function acceptRequest(donorRequestId) {

  try {

    const data = await postJSON(`/donor-request/${donorRequestId}/accept`);

    showToast(data.message, !data.success);

    if (data.success) {
      const item = document.getElementById(`request-item-${donorRequestId}`);
      if (item) item.remove();
    }

  } catch (err) {
    showToast("Could not accept the request. Please try again.", true);
  }

}


async function rejectRequest(donorRequestId) {

  try {

    const data = await postJSON(`/donor-request/${donorRequestId}/reject`);

    showToast(data.message, !data.success);

    if (data.success) {
      const item = document.getElementById(`request-item-${donorRequestId}`);
      if (item) item.remove();
    }

  } catch (err) {
    showToast("Could not reject the request. Please try again.", true);
  }

}


/* ---------- PAGE LOAD ---------- */

document.addEventListener("DOMContentLoaded", function() {
  console.log("BloodBridge frontend loaded successfully.");
});
